import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { postSchema, type postSchemaType } from "../../schemas/PostSchema";

export default function PostForm() {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<postSchemaType>({
    resolver: zodResolver(postSchema),
    defaultValues: { title: "", description: "", image_url: undefined },
  });

  const submit: SubmitHandler<postSchemaType> = (data) => {
    // data.image_url is a FileList -> upload data.image_url[0]
    console.log(data);
  };

  return (
    <form noValidate className="space-y-4" onSubmit={handleSubmit(submit)}>
      <label className="block text-sm font-semibold text-slate-700">
        Image
        <input {...register("image_url")} type="file" accept="image/jpeg,image/png,image/webp" aria-invalid={!!errors.image_url} className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100" />
        {errors.image_url && <p role="alert" className="text-red-500">{errors.image_url.message}</p>}
      </label>
      <label className="block text-sm font-semibold text-slate-700">
        Post title
        <input {...register("title")} type="text" placeholder="Enter a title" aria-invalid={!!errors.title} className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100" />
        {errors.title && <p role="alert" className="text-red-500">{errors.title.message}</p>}
      </label>
      <label className="block text-sm font-semibold text-slate-700">
        Description
        <textarea {...register("description")} placeholder="Write your post..." aria-invalid={!!errors.description} className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 resize-y" />
        {errors.description && <p role="alert" className="text-red-500">{errors.description.message}</p>}
      </label>
      <button type="submit" disabled={isSubmitting} className="w-full rounded-xl bg-indigo-600 px-4 py-3 font-bold text-white transition hover:bg-indigo-700 disabled:opacity-60">Publish post</button>
    </form>
  );
}